
package com.klef.fsad.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.Date;
import java.util.List;

public class ClientDemo {

    public static void main(String[] args) {

        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();

        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        Booking b1 = new Booking("Hotel Taj", new Date(), "CONFIRMED", 5000.0);
        Booking b2 = new Booking("Resort XYZ", new Date(), "PENDING", 3500.0);
        Booking b3 = new Booking("Guest House", new Date(), "CANCELLED", 2000.0);

        session.save(b1);
        session.save(b2);
        session.save(b3);

        Query<Booking> q1 = session.createQuery("from Booking", Booking.class);
        List<Booking> list = q1.list();
        System.out.println("All bookings:");
        for (Booking b : list) {
            System.out.println(b);
        }

        Query<Booking> q2 = session.createQuery("from Booking b where b.status = ?1", Booking.class);
        q2.setParameter(1, "CONFIRMED");
        List<Booking> confirmed = q2.list();
        System.out.println("Confirmed bookings (using positional parameter):");
        for (Booking b : confirmed) {
            System.out.println(b);
        }

        tx.commit();
        session.close();
        factory.close();
    }
}
